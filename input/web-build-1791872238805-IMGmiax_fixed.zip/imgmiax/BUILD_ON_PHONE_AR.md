# بناء APK من الهاتف عبر GitHub Actions

1. فك ضغط IMGmiax_AndroidStudio.zip.
2. أنشئ مستودعًا جديدًا على GitHub من المتصفح.
3. ارفع محتويات المجلد إلى جذر المستودع (يجب أن يظهر app/ وbuild.gradle.kts وsettings.gradle.kts و.github/workflows/android.yml مباشرة في الجذر).
4. افتح تبويب Actions في المستودع، واختر Build IMGmiax APK، ثم Run workflow.
5. انتظر انتهاء البناء بنجاح.
6. افتح تشغيل workflow الناجح وانزل إلى Artifacts، ثم نزّل IMGmiax-debug-apk.
7. فك ضغط ملف Artifact؛ ستجد app-debug.apk. افتحه للتثبيت واسمح للمتصفح/مدير الملفات بالتثبيت من هذا المصدر عند الطلب.

ملاحظات:
- يتطلب اتصال إنترنت وحساب GitHub.
- لا تضع كلمات مرور أو مفاتيح خاصة في المستودع.
- APK الناتج نسخة debug للتجربة.


ملاحظة: اسم الحزمة في النسخة الحالية هو `com.imgmiax.app`. لا ترفع ملفات اعتماد أو رموز GitHub داخل المشروع. إذا ظهر HTTP 401 في موقع البناء، احتفظ بعنوان URL الكامل من السجل (مع حذف أي token أو سر) لتحديد مصدر المصادقة.
