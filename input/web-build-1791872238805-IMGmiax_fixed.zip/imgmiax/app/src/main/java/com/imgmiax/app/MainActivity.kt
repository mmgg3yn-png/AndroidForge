package com.imgmiax.app

import android.app.Activity
import android.os.Bundle
import android.net.Uri
import android.content.Intent
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import java.io.*
import java.util.zip.*
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var pathText: TextView
    private var currentDir: DocumentFile? = null
    private val pickFolder = 100
    private val pickArchive = 101
    private val prefs by lazy { getSharedPreferences("fm", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(23,21,38)
        window.navigationBarColor = android.graphics.Color.rgb(23,21,38)
        buildUi()
        val saved = prefs.getString("tree", null)
        if (saved != null) {
            val uri = Uri.parse(saved)
            currentDir = DocumentFile.fromTreeUri(this, uri)
            render()
        } else showWelcome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF5F3FA.toInt()) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(14))
            setBackgroundColor(0xFF171526.toInt())
        }
        header.addView(TextView(this).apply {
            text = "IMGmiax"; textSize = 25f; setTextColor(-1); typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "مدير ملفات • أدوات IMG و BIN • أرشيفات"; textSize = 13f; setTextColor(0xFFD8D1F0.toInt())
            setPadding(0, dp(4), 0, dp(12))
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("اختيار مجلد") { chooseFolder() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        actions.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(actionButton("فتح ملف") { chooseArchive() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(actionButton("الإعدادات • المطور") { showDeveloper() })
        header.addView(actions)
        pathText = TextView(this).apply {
            textSize = 12f; setTextColor(0xFF514A65.toInt()); setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), dp(24)) }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(header)
        root.addView(pathText)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f
        setOnClickListener { action() }
    }

    private fun showWelcome() {
        list.removeAllViews()
        addInfo("ابدأ باختيار مجلد", "اختر مجلدًا من ذاكرة الهاتف لمنح التطبيق صلاحية الوصول إليه. لا يحتاج التطبيق إلى صلاحية الوصول الشامل للملفات.")
        addInfo("الصيغ المدعومة حاليًا", "ZIP وMTZ، ومعلومات IMG/BIN، وتحويل Android sparse IMG إلى raw IMG. استخراج super.img وأقسام ext4 ليس مدعومًا بعد في هذه النسخة.")
        addInfo("ملاحظة مهمة", "استخراج ملفات النظام من ext4/super.img وفتح أقسام dynamic partitions يحتاج محركًا متخصصًا؛ هذه النسخة لا تدّعي أنها تفك محتويات ext4 بالكامل.")
        pathText.text = "لم يتم اختيار مجلد"
    }

    private fun addInfo(title: String, desc: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(-1)
        }
        card.addView(TextView(this).apply { text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF211B35.toInt()) })
        card.addView(TextView(this).apply { text = desc; textSize = 13f; setTextColor(0xFF615B6D.toInt()); setPadding(0, dp(6), 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); list.addView(card, lp)
    }

    private fun showDeveloper() {
        val message = "اسم التطبيق: IMGmiax\nالمطور: محمد السعيد علي\nالبريد الإلكتروني: mmgg3yn@gmail.com\nقناة تلجرام: @Mi_Max12\n\nالميزات: مدير ملفات، استخراج ZIP/MTZ، فحص ترويسة IMG/BIN، وتحويل Android sparse IMG إلى raw.\n\nتنبيه: فك super.img وأقسام ext4 وملفات logo.bin الخاصة بالشركات يحتاج محللات متخصصة، ولا تعتبر هذه النسخة داعمة لاستخراج محتوياتها بالكامل."
        android.app.AlertDialog.Builder(this)
            .setTitle("المطور")
            .setMessage(message)
            .setPositiveButton("البريد الإلكتروني") { _, _ ->
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mmgg3yn@gmail.com"))
                try { startActivity(intent) } catch (_: Exception) { showMessage("البريد الإلكتروني", "mmgg3yn@gmail.com") }
            }
            .setNeutralButton("قناة تلجرام") { _, _ ->
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Mi_Max12"))
                try { startActivity(intent) } catch (_: Exception) { showMessage("تلجرام", "@Mi_Max12") }
            }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun chooseFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, pickFolder)
    }

    private fun chooseArchive() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, pickArchive)
    }

    @Deprecated("Deprecated in Android API but usable for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == pickFolder) {
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, flags)
            prefs.edit().putString("tree", uri.toString()).apply()
            currentDir = DocumentFile.fromTreeUri(this, uri)
            render()
        } else if (requestCode == pickArchive) handlePickedFile(uri)
    }

    private fun render() {
        list.removeAllViews()
        val dir = currentDir
        if (dir == null) { showWelcome(); return }
        pathText.text = "المجلد: ${dir.name ?: "Storage"}"
        val up = actionButton("↻ تحديث القائمة") { render() }
        list.addView(up)
        val children = dir.listFiles().sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { it.name?.lowercase(Locale.ROOT) ?: "" })
        if (children.isEmpty()) addInfo("المجلد فارغ", "لا توجد عناصر ظاهرة داخل هذا المجلد.")
        children.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(8), dp(10)); setBackgroundColor(-1)
                setOnClickListener {
                    if (file.isDirectory) { currentDir = file; render() }
                    else showFileActions(file)
                }
            }
            val icon = TextView(this).apply {
                text = if (file.isDirectory) "📁" else iconFor(file.name ?: "")
                textSize = 23f; setPadding(0, 0, dp(12), 0)
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply {
                text = file.name ?: "(بدون اسم)"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF241F33.toInt())
            })
            info.addView(TextView(this).apply {
                text = if (file.isDirectory) "مجلد" else humanSize(file.length())
                textSize = 11f; setTextColor(0xFF777181.toInt())
            })
            row.addView(icon)
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = "⋮"; textSize = 24f; setTextColor(0xFF6750A4.toInt()) })
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(4)
            list.addView(row, lp)
        }
    }

    private fun iconFor(name: String): String {
        val n = name.lowercase(Locale.ROOT)
        return when {
            n.endsWith(".zip") || n.endsWith(".mtz") || n.endsWith(".7z") || n.endsWith(".rar") -> "🗜️"
            n.endsWith(".img") || n.endsWith(".bin") || n.endsWith(".dat") -> "💽"
            n.endsWith(".apk") -> "📦"
            n.endsWith(".txt") || n.endsWith(".xml") -> "📄"
            else -> "📃"
        }
    }
    private fun humanSize(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024*1024 -> String.format(Locale.US, "%.1f KB", n/1024.0)
        else -> String.format(Locale.US, "%.1f MB", n/(1024.0*1024.0))
    }

    private fun showFileActions(file: DocumentFile) {
        val name = file.name ?: "file"
        val lower = name.lowercase(Locale.ROOT)
        val options = if (lower.endsWith(".img") || lower.endsWith(".bin") || lower.endsWith(".dat")) {
            if (lower.contains("super")) arrayOf("تحليل IMG/BIN", "تحويل sparse إلى raw", "فحص super.img", "معلومات الملف", "إلغاء")
            else arrayOf("تحليل IMG/BIN", "تحويل sparse إلى raw", "معلومات الملف", "إلغاء")
        } else arrayOf("استخراج هنا (ZIP/MTZ)", "معلومات الملف", "إلغاء")
        android.app.AlertDialog.Builder(this).setTitle(name).setItems(options) { _, which ->
            when {
                (lower.endsWith(".img") || lower.endsWith(".bin")) && which == 0 -> inspectImg(file)
                (lower.endsWith(".img") || lower.endsWith(".bin")) && which == 1 -> convertSparse(file)
                lower.contains("super") && (lower.endsWith(".img") || lower.endsWith(".bin") || lower.endsWith(".dat")) && which == 2 -> inspectSuper(file.uri, name)
                (lower.endsWith(".img") || lower.endsWith(".bin") || lower.endsWith(".dat")) && which == 2 && !lower.contains("super") -> fileInfo(file)
                lower.contains("super") && (lower.endsWith(".img") || lower.endsWith(".bin") || lower.endsWith(".dat")) && which == 3 -> fileInfo(file)
                !lower.endsWith(".img") && !lower.endsWith(".bin") && !lower.endsWith(".dat") && which == 0 -> extractZip(file)
                !lower.endsWith(".img") && !lower.endsWith(".bin") && !lower.endsWith(".dat") && which == 1 -> fileInfo(file)
            }
        }.show()
    }

    private fun handlePickedFile(uri: Uri) {
        val name = queryName(uri) ?: "selected_file"
        if (name.lowercase(Locale.ROOT).endsWith(".img") || name.lowercase(Locale.ROOT).endsWith(".bin")) {
            android.app.AlertDialog.Builder(this).setTitle(name)
                .setItems(arrayOf("تحليل IMG/BIN", "تحويل sparse إلى raw", "معلومات الملف", "إلغاء")) { _, w ->
                    if (w == 0) inspectImg(uri, name) else if (w == 1) convertSparse(uri, name) else if (w == 2) showMessage("معلومات الملف", "الاسم: $name\nالحجم: ${humanSize(querySize(uri))}")
                }.show()
        } else {
            android.app.AlertDialog.Builder(this).setTitle(name)
                .setItems(arrayOf("استخراج ZIP/MTZ إلى مجلد جديد", "معلومات الملف", "إلغاء")) { _, w ->
                    if (w == 0) extractZip(uri, name) else if (w == 1) showMessage("معلومات الملف", "الاسم: $name\nالحجم: ${humanSize(querySize(uri))}")
                }.show()
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }; return null
    }
    private fun querySize(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) return if (it.isNull(0)) 0 else it.getLong(0)
        }; return 0
    }
    private fun fileInfo(f: DocumentFile) = showMessage("معلومات الملف", "الاسم: ${f.name}\nالحجم: ${humanSize(f.length())}\nURI: ${f.uri}")
    private fun showMessage(title: String, msg: String) { android.app.AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("حسنًا", null).show() }

    private fun inspectImg(file: DocumentFile) = inspectImg(file.uri, file.name ?: "image.img")
    private fun inspectImg(uri: Uri, name: String) {
        try {
            contentResolver.openInputStream(uri)!!.use { input ->
                val h = ByteArray(4096); val count = input.read(h)
                val hex = h.take(minOf(count, 32)).joinToString(" ") { "%02X".format(it) }
                val magic = if (count >= 4) ((h[0].toLong() and 255) or ((h[1].toLong() and 255) shl 8) or ((h[2].toLong() and 255) shl 16) or ((h[3].toLong() and 255) shl 24)) else 0
                val type = when (magic) {
                    0xED26FF3AL -> "Android sparse image"
                    0xF2F52010L -> "قد يكون Android boot/vendor_boot (تحقق من الإصدار)"
                    else -> "IMG خام أو تنسيق آخر (لا يمكن تحديده بالامتداد وحده)"
                }
                showMessage("تحليل IMG", "الملف: $name\nالنوع المحتمل: $type\nأول 32 بايت:\n$hex\n\nملاحظة: تحديد النوع ليس ضمانًا أن الصورة قابلة للاستخراج.")
            }
        } catch (e: Exception) { showMessage("خطأ", e.message ?: "تعذر قراءة الملف") }
    }

    private fun inspectSuper(uri: Uri, name: String) {
        try {
            contentResolver.openInputStream(uri)!!.use { input ->
                val header = ByteArray(4096)
                val count = input.read(header)
                val bytes = if (count > 0) header.copyOf(count) else byteArrayOf()
                val hex = bytes.take(32).joinToString(" ") { "%02X".format(it) }
                val text = bytes.toString(Charsets.ISO_8859_1)
                val sparse = bytes.size >= 4 && (bytes[0].toInt() and 255) == 0x3A && (bytes[1].toInt() and 255) == 0xFF && (bytes[2].toInt() and 255) == 0x26 && (bytes[3].toInt() and 255) == 0xED
                val geometry = text.contains("gDla") || text.contains("\u0000gDla")
                val result = when {
                    sparse -> "الملف يبدأ بترويسة Android Sparse. حوّله إلى Raw أولًا ثم افحصه مجددًا."
                    geometry -> "تم العثور على توقيع محتمل لبيانات super (LP metadata). هذا فحص أولي فقط؛ لا يستخرج الأقسام."
                    else -> "لم يُعثر على توقيع super واضح في أول 4096 بايت. قد تكون الصورة raw أو بتنسيق/إزاحة مختلفة."
                }
                showMessage("فحص super.img", "الملف: $name\nالحجم: ${humanSize(querySize(uri))}\n$result\n\nأول البايتات: $hex\n\nملاحظة: استخراج أقسام dynamic partitions يحتاج محلل liblp كاملًا، وهذا الفحص لا يفك الأقسام.")
            }
        } catch (e: Exception) { showMessage("خطأ", e.message ?: "تعذر قراءة الملف") }
    }

    private fun convertSparse(file: DocumentFile) = convertSparse(file.uri, file.name ?: "image.img")
    private fun convertSparse(uri: Uri, name: String) {
        val parent = currentDir
        if (parent == null) { showMessage("اختر مجلدًا", "اختر مجلدًا أولًا ليتم حفظ الناتج داخله."); return }
        Thread {
            try {
                val rawName = name.substringBeforeLast('.', name) + "_raw.img"
                val out = parent.createFile("application/octet-stream", rawName) ?: throw IOException("تعذر إنشاء ملف الناتج")
                contentResolver.openInputStream(uri)!!.use { input ->
                    out.uri.let { outputUri ->
                        contentResolver.openOutputStream(outputUri, "w")!!.use { output -> sparseToRaw(input, output) }
                    }
                }
                runOnUiThread { showMessage("اكتمل التحويل", "تم حفظ $rawName داخل المجلد الحالي.") ; render() }
            } catch (e: Exception) {
                runOnUiThread { showMessage("فشل التحويل", e.message ?: "الملف ليس Android sparse صالحًا أو حدث خطأ قراءة/كتابة.") }
            }
        }.start()
    }

    // Android sparse image format v1: RAW, FILL, DONT_CARE, CRC32 chunks.
    private fun sparseToRaw(input: InputStream, output: OutputStream) {
        val d = DataInputStream(BufferedInputStream(input))
        fun u16(): Int = java.lang.Short.toUnsignedInt(java.lang.Short.reverseBytes(d.readShort()))
        fun u32(): Long = Integer.toUnsignedLong(Integer.reverseBytes(d.readInt()))
        val magic = u32()
        if (magic != 0xED26FF3AL) throw IOException("التوقيع ليس Android sparse image (magic غير مطابق)")
        val major = u16(); val minor = u16()
        val fileHdrSz = u16(); val chunkHdrSz = u16()
        val blockSize = u32(); val totalBlocks = u32(); val totalChunks = u32()
        u32() // image checksum
        if (major != 1 || fileHdrSz < 28 || chunkHdrSz < 12 || blockSize <= 0 || totalChunks > 2_000_000) throw IOException("رأس sparse غير مدعوم أو تالف")
        if (fileHdrSz > 28) d.skipBytes(fileHdrSz - 28)
        var writtenBlocks = 0L
        val buffer = ByteArray(64 * 1024)
        repeat(totalChunks.toInt()) {
            val type = u16()
            u16() // reserved
            val chunkBlocks = u32()
            val totalSize = u32()
            if (chunkHdrSz > 12) d.skipBytes(chunkHdrSz - 12)
            val bytes = chunkBlocks * blockSize
            when (type) {
                0xCAC1 -> { // RAW
                    var remain = bytes
                    while (remain > 0) {
                        val n = d.read(buffer, 0, minOf(buffer.size.toLong(), remain).toInt())
                        if (n < 0) throw EOFException("انتهى الملف داخل RAW chunk")
                        output.write(buffer, 0, n); remain -= n
                    }
                }
                0xCAC2 -> { // FILL
                    val pattern = ByteArray(4); d.readFully(pattern)
                    val fill = ByteArray(64 * 1024)
                    var i = 0
                    while (i < fill.size) { for (j in 0..3) fill[i+j] = pattern[j]; i += 4 }
                    var remain = bytes
                    while (remain > 0) { val n = minOf(fill.size.toLong(), remain).toInt(); output.write(fill, 0, n); remain -= n }
                }
                0xCAC3 -> { // DONT_CARE -> zero fill for portable raw output
                    val zero = ByteArray(64 * 1024); var remain = bytes
                    while (remain > 0) { val n = minOf(zero.size.toLong(), remain).toInt(); output.write(zero, 0, n); remain -= n }
                }
                0xCAC4 -> { // CRC32
                    if (totalSize >= chunkHdrSz + 4) d.skipBytes(4)
                    val extra = totalSize - chunkHdrSz - 4
                    if (extra > 0) d.skipBytes(extra.toInt())
                }
                else -> throw IOException("نوع chunk غير معروف: 0x${type.toString(16)}")
            }
            writtenBlocks += chunkBlocks
        }
        if (writtenBlocks != totalBlocks) throw IOException("عدد الكتل لا يطابق رأس الملف")
        output.flush()
    }

    private fun extractZip(file: DocumentFile) = extractZip(file.uri, file.name ?: "archive.zip")
    private fun extractZip(uri: Uri, name: String) {
        val dir = currentDir
        if (dir == null) { showMessage("اختر مجلدًا", "اختر مجلدًا أولًا."); return }
        Thread {
            try {
                val folderName = name.substringBeforeLast('.', name) + "_extracted"
                val dest = dir.createDirectory(folderName) ?: throw IOException("تعذر إنشاء مجلد الاستخراج")
                var count = 0
                contentResolver.openInputStream(uri)!!.use { raw ->
                    ZipInputStream(BufferedInputStream(raw)).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            val clean = entry.name.replace('\\', '/')
                            if (clean.startsWith("/") || clean.split("/").any { it == ".." }) throw IOException("الأرشيف يحتوي مسارًا غير آمن")
                            var target = dest
                            val parts = clean.split("/").filter { it.isNotEmpty() }
                            if (parts.isNotEmpty()) {
                                for (part in parts.dropLast(1)) target = target.findFile(part) ?: target.createDirectory(part) ?: throw IOException("تعذر إنشاء مجلد: $part")
                                if (entry.isDirectory) target.createDirectory(parts.last())
                                else {
                                    val f = target.createFile("application/octet-stream", parts.last()) ?: throw IOException("تعذر إنشاء الملف: ${parts.last()}")
                                    contentResolver.openOutputStream(f.uri, "w")!!.use { out ->
                                        val buf = ByteArray(32 * 1024); var n: Int
                                        while (zip.read(buf).also { n = it } > 0) out.write(buf, 0, n)
                                    }
                                    count++
                                }
                            }
                            zip.closeEntry(); entry = zip.nextEntry
                        }
                    }
                }
                runOnUiThread { showMessage("اكتمل الاستخراج", "تم استخراج $count ملفًا إلى ${dest.name}."); render() }
            } catch (e: Exception) { runOnUiThread { showMessage("فشل الاستخراج", e.message ?: "ملف غير مدعوم أو تالف") } }
        }.start()
    }
}
