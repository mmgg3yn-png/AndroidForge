# IMGmiax — مشروع Android Studio

## ما الذي يعمل في هذه النسخة؟
- واجهة مدير ملفات عربية بسيطة، اختيار مجلد عبر منتقي ملفات Android، تصفح المجلدات وعرض الحجم.
- استخراج أرشيفات ZIP وملفات MTZ المبنية على ZIP إلى مجلد جديد.
- قراءة أول ترويسة من ملفات IMG وعرض توقيعها المحتمل.
- تحويل Android sparse IMG إلى raw IMG، مع معالجة RAW/FILL/DONT_CARE/CRC32 chunks.

## ما الذي لا تدّعي النسخة دعمه؟
- لا تفك محتويات ext4 أو super.img/dynamic partitions داخل IMG حتى الآن.
- لا تدعم RAR و7z فعليًا رغم عرض أيقونة أرشيف لها.
- MTZ غير القياسي أو المشفر قد لا يُفتح.
- تحويل sparse إلى raw يحتاج مساحة فارغة تقارب الحجم الخام النهائي؛ وكتل DONT_CARE تتحول إلى أصفار.
- لا تومض الرومات ولا تكتب إلى أقسام الهاتف.

## البناء
1. فك ملف ZIP.
2. افتح مجلد `IMGmiax` في Android Studio حديث.
3. اسمح له بتنزيل Gradle وAndroid SDK المطلوبة.
4. من القائمة Build اختر Build APK(s).
5. الناتج عادة في `app/build/outputs/apk/debug/app-debug.apk`.

## المتطلبات
- Android Studio حديث وJDK 17.
- compileSdk 35 وAndroid Gradle Plugin 8.7.3.


## تحديثات IMGmiax
- تم توحيد package وnamespace وapplicationId إلى `com.imgmiax.app`.
- تم تحديث اسم المشروع إلى IMGmiax.
- أضيف فحص أولي لترويسة `super.img`، لكنه لا يستخرج dynamic partitions أو ext4.
- تحويل Android Sparse إلى Raw متاح، وهو مختلف عن استخراج ملفات النظام.
- خطأ HTTP 401 من موقع بناء خارجي لا يمكن إصلاحه بتعديل Gradle وحده؛ يجب فحص رابط API الذي يعرضه سجل الموقع.
- لا يتضمن الأرشيف Gradle Wrapper؛ يمكن للموقع استخدام Gradle المثبت على الخادم.
